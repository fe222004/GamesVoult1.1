export interface GamesI {
    nombre:string;
    descripcion:string;
    fechaActualizacion:Date;
    idioma:string;
    peso:string;
    version:string;
    imagen:string;
    archivo:string;
}